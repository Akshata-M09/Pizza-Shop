let listProductHTML = document.querySelector(".listProduct");
let listCartHTML = document.querySelector(".listCart");
let iconCart = document.querySelector(".icon-cart");
let iconCartSpan = document.querySelector(".icon-cart span");
let body = document.querySelector("body");
let closeCart = document.querySelector(".close");
let products = [];
let cart = [];

// Toggle cart visibility
iconCart.addEventListener("click", () => {
  let isCartVisible = body.classList.toggle("showCart");
  sessionStorage.setItem("cartVisible", isCartVisible);
});

closeCart.addEventListener("click", () => {
  body.classList.remove("showCart");
  sessionStorage.setItem("cartVisible", false);
});

// Add products to HTML
const addDataToHTML = () => {
  listProductHTML.innerHTML = "";
  // for adding cards
  if (products.length > 0) {
    products.forEach((product) => {
      let newProduct = document.createElement("div");
      newProduct.dataset.id = product.id;
      newProduct.classList.add("item"); //classList
      newProduct.innerHTML = `
        <img src="${product.image}" alt="${product.name}" />
        <h4>${product.name}</h4>
        <div class="price">${product.price}</div>
        <button class="addCart">Add To Cart</button>
      `;
      listProductHTML.appendChild(newProduct);
    });
  }
};

// Handle adding a product to the cart
listProductHTML.addEventListener("click", (event) => {
  if (event.target.classList.contains("addCart")) {
    let id_product = event.target.parentElement.dataset.id;
    addToCart(id_product);
  }
});

const addToCart = (product_id) => {
  let positionThisProductInCart = cart.findIndex(
    (item) => item.product_id == product_id
  );

  if (positionThisProductInCart < 0) {
    // add product to cart[] with quantity 1
    cart.push({
      product_id: product_id,
      quantity: 1,
    });
  } else {
    cart[positionThisProductInCart].quantity += 1;
  }

  addCartToHTML();
  addCartToMemory();
};

// Save cart to local storage
const addCartToMemory = () => {
  localStorage.setItem("cart", JSON.stringify(cart));
};

// Add cart items to HTML...updates the cart ui
const addCartToHTML = () => {
  listCartHTML.innerHTML = ""; // Clear previous cart data
  let totalQuantity = 0;
  let totalAmount = 0;

  if (cart.length > 0) {
    cart.forEach((item) => {
      let positionProduct = products.findIndex(
        (product) => product.id == item.product_id
      );

      // Check if product exists in the products list
      if (positionProduct >= 0) {
        let info = products[positionProduct];
        let price = parseFloat(info.price.replace(/[^\d.-]/g, "")) || 0;
        let quantity = item.quantity || 1; // Ensure quantity is valid
        totalQuantity += quantity;
        totalAmount += price * quantity;

        let newItem = document.createElement("div");
        newItem.classList.add("item");
        newItem.dataset.id = item.product_id;

        newItem.innerHTML = `
          <div class="image">
            <img src="${info.image}" alt="${info.name}" />
          </div>
          <div class="name">${info.name}</div>
          <div class="totalPrice">₹${(price * quantity).toFixed(2)}</div>
          <div class="quantity">
            <span class="minus">-</span>
            <span>${quantity}</span>
            <span class="plus">+</span>
          </div>
        `;
        listCartHTML.appendChild(newItem);
      }
    });

    //total amount display
    let totalAmountDiv = document.createElement("div");
    totalAmountDiv.classList.add("total-amount");
    totalAmountDiv.innerHTML = `<h3>Total: ₹${totalAmount.toFixed(2)}</h3>`;
    listCartHTML.appendChild(totalAmountDiv);
  }

  // Update cart quantity indicator in cart icon
  iconCartSpan.innerText = totalQuantity;
};

// for quantity changes in the cart
listCartHTML.addEventListener("click", (event) => {
  if (
    event.target.classList.contains("minus") ||
    event.target.classList.contains("plus")
  ) {
    let product_id = event.target.parentElement.parentElement.dataset.id;
    let type = event.target.classList.contains("plus") ? "plus" : "minus";
    changeQuantityCart(product_id, type);
  }
});

const changeQuantityCart = (product_id, type) => {
  let positionItemInCart = cart.findIndex(
    (item) => item.product_id == product_id
  );

  if (positionItemInCart >= 0) {
    switch (type) {
      case "plus":
        cart[positionItemInCart].quantity += 1;
        break;

      case "minus":
        if (cart[positionItemInCart].quantity > 1) {
          cart[positionItemInCart].quantity -= 1;
        } else {
          cart.splice(positionItemInCart, 1); // Remove item if quantity is 0
        }
        break;
    }
  }

  addCartToHTML();
  addCartToMemory();
};

// Initialize application
const initApp = () => {
  // Fetch product data
  fetch("products.json")
    .then((response) => response.json())
    .then((data) => {
      products = data;

      addDataToHTML();

      // Load cart data from local storage
      if (localStorage.getItem("cart")) {
        cart = JSON.parse(localStorage.getItem("cart"));
        addCartToHTML();
      }

      let cartVisible = sessionStorage.getItem("cartVisible") === "true";
      if (cartVisible) {
        body.classList.add("showCart");
      } else {
        body.classList.remove("showCart");
      }
    })
    .catch((error) => console.error("Error loading products:", error)); // Handle fetch errors
};

initApp();
