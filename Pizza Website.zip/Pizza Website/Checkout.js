function openQRCodeWindow(paymentUrl, title) {
  const qrWindow = window.open("", "_blank", "width=400,height=600");

  if (!qrWindow) {
    alert("Popup blocked. Please allow popups for this site.");
    return;
  }

  qrWindow.document.write(`
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${title}</title>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
        <style>
          body { font-family: Arial, sans-serif; text-align: center; padding: 20px; }
          #qr-code { margin: 20px auto; }
          button { margin-top: 20px; padding: 10px 20px; font-size: 16px; cursor: pointer; }
        </style>
      </head>
      <body>
        <h1>${title}</h1>
        <div id="qr-code"></div>
        <button onclick="window.close()">Close</button>
        <script>
          new QRCode(document.getElementById("qr-code"), {
            text: "${paymentUrl}",
            width: 256,
            height: 240,
          });
        </script>
      </body>
    </html>
  `);

  qrWindow.document.close();
}

// gpay
document.querySelector(".gpay-btn").addEventListener("click", () => {
  const gpayUrl = "https://pay.google.com/gp/w/u/0/home";
  openQRCodeWindow(gpayUrl, "Google Pay QR Code");
});

// paytm
document.querySelector(".paytm-btn").addEventListener("click", () => {
  const paytmUrl = "https://paytm.com/pay";
  openQRCodeWindow(paytmUrl, "Paytm QR Code");
});
